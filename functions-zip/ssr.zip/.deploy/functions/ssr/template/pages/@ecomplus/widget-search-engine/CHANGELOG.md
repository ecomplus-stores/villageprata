# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-beta.143](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.142...@ecomplus/widget-search-engine@1.0.0-beta.143) (2023-02-23)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.142](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.141...@ecomplus/widget-search-engine@1.0.0-beta.142) (2023-02-09)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.141](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.140...@ecomplus/widget-search-engine@1.0.0-beta.141) (2023-01-25)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.140](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.139...@ecomplus/widget-search-engine@1.0.0-beta.140) (2023-01-20)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.139](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.138...@ecomplus/widget-search-engine@1.0.0-beta.139) (2023-01-09)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.138](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.137...@ecomplus/widget-search-engine@1.0.0-beta.138) (2022-12-29)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.137](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.136...@ecomplus/widget-search-engine@1.0.0-beta.137) (2022-11-10)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.136](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.135...@ecomplus/widget-search-engine@1.0.0-beta.136) (2022-11-04)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.135](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.134...@ecomplus/widget-search-engine@1.0.0-beta.135) (2022-11-01)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.134](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.133...@ecomplus/widget-search-engine@1.0.0-beta.134) (2022-10-25)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.133](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.132...@ecomplus/widget-search-engine@1.0.0-beta.133) (2022-09-15)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.132](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.131...@ecomplus/widget-search-engine@1.0.0-beta.132) (2022-09-01)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.131](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.130...@ecomplus/widget-search-engine@1.0.0-beta.131) (2022-08-26)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.130](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.129...@ecomplus/widget-search-engine@1.0.0-beta.130) (2022-08-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.129](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.128...@ecomplus/widget-search-engine@1.0.0-beta.129) (2022-08-04)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.128](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.127...@ecomplus/widget-search-engine@1.0.0-beta.128) (2022-07-28)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.127](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.126...@ecomplus/widget-search-engine@1.0.0-beta.127) (2022-07-26)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.126](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.125...@ecomplus/widget-search-engine@1.0.0-beta.126) (2022-07-16)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.125](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.124...@ecomplus/widget-search-engine@1.0.0-beta.125) (2022-07-06)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.124](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.123...@ecomplus/widget-search-engine@1.0.0-beta.124) (2022-07-04)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.123](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.122...@ecomplus/widget-search-engine@1.0.0-beta.123) (2022-06-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.122](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.121...@ecomplus/widget-search-engine@1.0.0-beta.122) (2022-05-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.121](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.120...@ecomplus/widget-search-engine@1.0.0-beta.121) (2022-05-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.120](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.119...@ecomplus/widget-search-engine@1.0.0-beta.120) (2022-05-14)

### Bug Fixes

- **widget-search-engine:** force div min height when replacing search snap ([cc8fd29](https://github.com/ecomplus/storefront/commit/cc8fd29273d319cb7966499acf7c509dc1649a93))

# [1.0.0-beta.119](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.118...@ecomplus/widget-search-engine@1.0.0-beta.119) (2022-05-06)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.118](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.117...@ecomplus/widget-search-engine@1.0.0-beta.118) (2022-04-21)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.117](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.116...@ecomplus/widget-search-engine@1.0.0-beta.117) (2022-04-01)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.116](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.115...@ecomplus/widget-search-engine@1.0.0-beta.116) (2022-03-05)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.115](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.114...@ecomplus/widget-search-engine@1.0.0-beta.115) (2022-02-16)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.114](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.113...@ecomplus/widget-search-engine@1.0.0-beta.114) (2022-02-06)

### Features

- **template/cms:** using @ecomplus/storefront-cms in place of raw netlify cms ([#596](https://github.com/ecomplus/storefront/issues/596)) ([95c8d3a](https://github.com/ecomplus/storefront/commit/95c8d3ab3f73b0b1dff0a1f5f45b5abfb6dddafa)), closes [#issuecomment-1006566949](https://github.com/ecomplus/storefront/issues/issuecomment-1006566949) [#issuecomment-1003380562](https://github.com/ecomplus/storefront/issues/issuecomment-1003380562)

# [1.0.0-beta.113](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.112...@ecomplus/widget-search-engine@1.0.0-beta.113) (2022-01-24)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.112](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.111...@ecomplus/widget-search-engine@1.0.0-beta.112) (2022-01-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.111](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.110...@ecomplus/widget-search-engine@1.0.0-beta.111) (2022-01-11)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.110](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.109...@ecomplus/widget-search-engine@1.0.0-beta.110) (2022-01-04)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.109](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.108...@ecomplus/widget-search-engine@1.0.0-beta.109) (2021-12-31)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.108](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.107...@ecomplus/widget-search-engine@1.0.0-beta.108) (2021-12-29)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.107](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.106...@ecomplus/widget-search-engine@1.0.0-beta.107) (2021-12-06)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.106](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.105...@ecomplus/widget-search-engine@1.0.0-beta.106) (2021-11-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.105](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.104...@ecomplus/widget-search-engine@1.0.0-beta.105) (2021-11-09)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.104](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.103...@ecomplus/widget-search-engine@1.0.0-beta.104) (2021-11-09)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.103](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.102...@ecomplus/widget-search-engine@1.0.0-beta.103) (2021-10-25)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.102](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.101...@ecomplus/widget-search-engine@1.0.0-beta.102) (2021-10-05)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.101](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.100...@ecomplus/widget-search-engine@1.0.0-beta.101) (2021-10-05)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.100](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.99...@ecomplus/widget-search-engine@1.0.0-beta.100) (2021-09-21)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.99](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.98...@ecomplus/widget-search-engine@1.0.0-beta.99) (2021-09-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.98](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.97...@ecomplus/widget-search-engine@1.0.0-beta.98) (2021-09-02)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.97](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.96...@ecomplus/widget-search-engine@1.0.0-beta.97) (2021-08-19)

### Features

- **widget-search-engine/url-params:** test `sort` option from url param ([6a8cdd0](https://github.com/ecomplus/storefront/commit/6a8cdd0eef6b94ed69828736b1aee17ec8f196c6))

# [1.0.0-beta.96](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.95...@ecomplus/widget-search-engine@1.0.0-beta.96) (2021-08-17)

### Features

- **widget-search-engine/options:** handle disable filters and load more options from el dataset ([8171600](https://github.com/ecomplus/storefront/commit/8171600eb57c014395aa237ec94c2caeb9ebc494))

# [1.0.0-beta.95](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.94...@ecomplus/widget-search-engine@1.0.0-beta.95) (2021-08-02)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.94](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.93...@ecomplus/widget-search-engine@1.0.0-beta.94) (2021-07-30)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.93](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.92...@ecomplus/widget-search-engine@1.0.0-beta.93) (2021-07-24)

### Bug Fixes

- **widget-search-engine/url:** prevent pushing to navigator history when no query to set ([d56c8f0](https://github.com/ecomplus/storefront/commit/d56c8f0cc94409d06596dfd66178cad613c4a158))

# [1.0.0-beta.92](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.91...@ecomplus/widget-search-engine@1.0.0-beta.92) (2021-07-08)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.91](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.90...@ecomplus/widget-search-engine@1.0.0-beta.91) (2021-07-02)

### Features

- **widget-search-engine/cms:** add pagination to config options [[#451](https://github.com/ecomplus/storefront/issues/451)] ([6c97eff](https://github.com/ecomplus/storefront/commit/6c97eff38fd921831d0e5d33e092932523934772))
- **widget-search-engine/pagination:** handle pagination option with `APagination` component [[#451](https://github.com/ecomplus/storefront/issues/451)] ([662cec7](https://github.com/ecomplus/storefront/commit/662cec7ba744bd746c8551a183a54350cf350eab))

# [1.0.0-beta.90](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.89...@ecomplus/widget-search-engine@1.0.0-beta.90) (2021-06-21)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.89](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.88...@ecomplus/widget-search-engine@1.0.0-beta.89) (2021-06-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.88](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.87...@ecomplus/widget-search-engine@1.0.0-beta.88) (2021-06-11)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.87](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.86...@ecomplus/widget-search-engine@1.0.0-beta.87) (2021-05-27)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.86](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.85...@ecomplus/widget-search-engine@1.0.0-beta.86) (2021-05-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.85](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.84...@ecomplus/widget-search-engine@1.0.0-beta.85) (2021-05-14)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.84](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.83...@ecomplus/widget-search-engine@1.0.0-beta.84) (2021-04-28)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.83](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.82...@ecomplus/widget-search-engine@1.0.0-beta.83) (2021-03-29)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.82](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.81...@ecomplus/widget-search-engine@1.0.0-beta.82) (2021-03-12)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.81](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.80...@ecomplus/widget-search-engine@1.0.0-beta.81) (2021-02-24)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.80](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.79...@ecomplus/widget-search-engine@1.0.0-beta.80) (2021-02-15)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.79](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.78...@ecomplus/widget-search-engine@1.0.0-beta.79) (2021-01-25)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.78](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.77...@ecomplus/widget-search-engine@1.0.0-beta.78) (2021-01-15)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.77](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.76...@ecomplus/widget-search-engine@1.0.0-beta.77) (2021-01-14)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.76](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.75...@ecomplus/widget-search-engine@1.0.0-beta.76) (2020-12-24)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.75](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.74...@ecomplus/widget-search-engine@1.0.0-beta.75) (2020-12-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.74](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.73...@ecomplus/widget-search-engine@1.0.0-beta.74) (2020-12-16)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.73](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.72...@ecomplus/widget-search-engine@1.0.0-beta.73) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.72](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.71...@ecomplus/widget-search-engine@1.0.0-beta.72) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.71](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.70...@ecomplus/widget-search-engine@1.0.0-beta.71) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.70](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.69...@ecomplus/widget-search-engine@1.0.0-beta.70) (2020-12-07)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.69](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.68...@ecomplus/widget-search-engine@1.0.0-beta.69) (2020-12-04)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.68](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.67...@ecomplus/widget-search-engine@1.0.0-beta.68) (2020-12-01)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.67](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.66...@ecomplus/widget-search-engine@1.0.0-beta.67) (2020-11-27)

### Features

- **search-url-params:** parse 'filters[]' param to search engine default filters ([#362](https://github.com/ecomplus/storefront/issues/362)) ([b7e9178](https://github.com/ecomplus/storefront/commit/b7e91780e0d961eab953ab748a1a479b1221e9c8))

# [1.0.0-beta.66](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.65...@ecomplus/widget-search-engine@1.0.0-beta.66) (2020-11-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.65](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.64...@ecomplus/widget-search-engine@1.0.0-beta.65) (2020-11-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.64](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.63...@ecomplus/widget-search-engine@1.0.0-beta.64) (2020-11-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.63](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.62...@ecomplus/widget-search-engine@1.0.0-beta.63) (2020-11-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.62](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.61...@ecomplus/widget-search-engine@1.0.0-beta.62) (2020-11-12)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.61](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.60...@ecomplus/widget-search-engine@1.0.0-beta.61) (2020-11-09)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.60](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.59...@ecomplus/widget-search-engine@1.0.0-beta.60) (2020-11-03)

### Features

- **widget-search-engine:** handling default sort option from el dataset ([4d00fc1](https://github.com/ecomplus/storefront/commit/4d00fc1d75083af8047e4a9ac6fee3c536b9334f))

# [1.0.0-beta.59](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.58...@ecomplus/widget-search-engine@1.0.0-beta.59) (2020-10-26)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.58](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.57...@ecomplus/widget-search-engine@1.0.0-beta.58) (2020-10-14)

### Bug Fixes

- **search-engine-hydrate:** render new items if prerendered has diferent ids ([6135803](https://github.com/ecomplus/storefront/commit/613580322eb2d25673a96305ecade2814d1fb681))

# [1.0.0-beta.57](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.56...@ecomplus/widget-search-engine@1.0.0-beta.57) (2020-10-06)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.56](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.55...@ecomplus/widget-search-engine@1.0.0-beta.56) (2020-10-02)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.55](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.54...@ecomplus/widget-search-engine@1.0.0-beta.55) (2020-09-14)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.54](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.53...@ecomplus/widget-search-engine@1.0.0-beta.54) (2020-09-11)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.53](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.52...@ecomplus/widget-search-engine@1.0.0-beta.53) (2020-09-11)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.52](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.51...@ecomplus/widget-search-engine@1.0.0-beta.52) (2020-09-10)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.51](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.50...@ecomplus/widget-search-engine@1.0.0-beta.51) (2020-09-10)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.50](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.49...@ecomplus/widget-search-engine@1.0.0-beta.50) (2020-08-27)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.49](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.48...@ecomplus/widget-search-engine@1.0.0-beta.49) (2020-08-27)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.48](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.47...@ecomplus/widget-search-engine@1.0.0-beta.48) (2020-08-20)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.47](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.46...@ecomplus/widget-search-engine@1.0.0-beta.47) (2020-08-19)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.46](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.45...@ecomplus/widget-search-engine@1.0.0-beta.46) (2020-08-17)

### Bug Fixes

- **deps:** add @ecomplus/storefront-twbs to direct deps ([cf9d0ad](https://github.com/ecomplus/storefront/commit/cf9d0adf0c8d261b9e68c9076f342d644aad9e7c))
- **widget-search-engine:** use `loadMoreSelector` when retail is prerendered (ssr) ([8eaeb68](https://github.com/ecomplus/storefront/commit/8eaeb68f27946163a64026a62c38cdaad71ccf3d))

# [1.0.0-beta.45](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.44...@ecomplus/widget-search-engine@1.0.0-beta.45) (2020-08-14)

### Performance Improvements

- **widget-search-engine:** better hydration for brands/categories ([93fac25](https://github.com/ecomplus/storefront/commit/93fac25362602a6776db83b51944537cf5ac6aa8))

# [1.0.0-beta.44](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.43...@ecomplus/widget-search-engine@1.0.0-beta.44) (2020-08-12)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.43](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.42...@ecomplus/widget-search-engine@1.0.0-beta.43) (2020-08-11)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.42](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.41...@ecomplus/widget-search-engine@1.0.0-beta.42) (2020-08-10)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.41](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.40...@ecomplus/widget-search-engine@1.0.0-beta.41) (2020-08-04)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.40](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.39...@ecomplus/widget-search-engine@1.0.0-beta.40) (2020-07-29)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.39](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.38...@ecomplus/widget-search-engine@1.0.0-beta.39) (2020-07-20)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.38](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.37...@ecomplus/widget-search-engine@1.0.0-beta.38) (2020-07-17)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.37](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.36...@ecomplus/widget-search-engine@1.0.0-beta.37) (2020-07-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.36](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.35...@ecomplus/widget-search-engine@1.0.0-beta.36) (2020-07-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.35](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.34...@ecomplus/widget-search-engine@1.0.0-beta.35) (2020-07-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.34](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.33...@ecomplus/widget-search-engine@1.0.0-beta.34) (2020-07-02)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.33](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.32...@ecomplus/widget-search-engine@1.0.0-beta.33) (2020-06-30)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.32](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.31...@ecomplus/widget-search-engine@1.0.0-beta.32) (2020-06-25)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.31](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.30...@ecomplus/widget-search-engine@1.0.0-beta.31) (2020-06-21)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.30](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.29...@ecomplus/widget-search-engine@1.0.0-beta.30) (2020-06-21)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.29](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.28...@ecomplus/widget-search-engine@1.0.0-beta.29) (2020-06-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.28](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.27...@ecomplus/widget-search-engine@1.0.0-beta.28) (2020-06-18)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.27](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.26...@ecomplus/widget-search-engine@1.0.0-beta.27) (2020-06-10)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.26](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.25...@ecomplus/widget-search-engine@1.0.0-beta.26) (2020-06-06)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.25](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.24...@ecomplus/widget-search-engine@1.0.0-beta.25) (2020-06-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.24](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.23...@ecomplus/widget-search-engine@1.0.0-beta.24) (2020-06-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.23](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.22...@ecomplus/widget-search-engine@1.0.0-beta.23) (2020-06-02)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.22](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.21...@ecomplus/widget-search-engine@1.0.0-beta.22) (2020-06-02)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.21](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.20...@ecomplus/widget-search-engine@1.0.0-beta.21) (2020-05-28)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.20](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.19...@ecomplus/widget-search-engine@1.0.0-beta.20) (2020-05-28)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.19](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.18...@ecomplus/widget-search-engine@1.0.0-beta.19) (2020-05-28)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.18](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.17...@ecomplus/widget-search-engine@1.0.0-beta.18) (2020-05-26)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.17](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.16...@ecomplus/widget-search-engine@1.0.0-beta.17) (2020-05-26)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.16](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.15...@ecomplus/widget-search-engine@1.0.0-beta.16) (2020-05-24)

### Bug Fixes

- **widget-search-engine:** handling term prop update (sync) ([e69877e](https://github.com/ecomplus/storefront/commit/e69877e87711bc77b1cd7ce0abbf53ca5b50ac31))

# [1.0.0-beta.15](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.14...@ecomplus/widget-search-engine@1.0.0-beta.15) (2020-05-23)

### Bug Fixes

- **widget-search-engine:** ensure checking filters for brands/categories ([7d525e3](https://github.com/ecomplus/storefront/commit/7d525e3e6e70f0298270370b2208b457bfbd2449))

# [1.0.0-beta.14](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.13...@ecomplus/widget-search-engine@1.0.0-beta.14) (2020-05-22)

### Bug Fixes

- **widget-search-engine:** prevent no filters on categories/brands pages ([9742b1a](https://github.com/ecomplus/storefront/commit/9742b1abcb262a48cd8e38455290d939a28acd38))

# [1.0.0-beta.13](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.12...@ecomplus/widget-search-engine@1.0.0-beta.13) (2020-05-22)

### Bug Fixes

- **deps:** update @ecomplus/utils to v1.4.0 ([551e02e](https://github.com/ecomplus/storefront/commit/551e02e0e1e3bee6ce7002fd84d0c91f9cb8fb08))
- **widget-seacrh-engine:** set default sort 'sales' for category/brands ([bf99ca5](https://github.com/ecomplus/storefront/commit/bf99ca5671182a02aff5d1e7876d29bf7da85d3e))
- **widget-search-engine:** get filters from data for categories/brands ([4d0acae](https://github.com/ecomplus/storefront/commit/4d0acaea65d584f2d59386adb1532344aa8315d5))

# [1.0.0-beta.12](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.11...@ecomplus/widget-search-engine@1.0.0-beta.12) (2020-05-22)

### Bug Fixes

- **widget-search-engine:** fix setting props on brands/categories pages ([c5a3dd0](https://github.com/ecomplus/storefront/commit/c5a3dd06e6c865846f95e061357097d3e804bff3))

# [1.0.0-beta.11](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.10...@ecomplus/widget-search-engine@1.0.0-beta.11) (2020-05-21)

### Features

- **search-engine:** also handling brands/categories pages ([7180cd0](https://github.com/ecomplus/storefront/commit/7180cd016a6f213624dca8d4179594bccf084535))

# [1.0.0-beta.10](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.9...@ecomplus/widget-search-engine@1.0.0-beta.10) (2020-05-16)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.9](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.8...@ecomplus/widget-search-engine@1.0.0-beta.9) (2020-05-16)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.8](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.7...@ecomplus/widget-search-engine@1.0.0-beta.8) (2020-05-14)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.7](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.6...@ecomplus/widget-search-engine@1.0.0-beta.7) (2020-05-12)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.6](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.5...@ecomplus/widget-search-engine@1.0.0-beta.6) (2020-05-08)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.5](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.4...@ecomplus/widget-search-engine@1.0.0-beta.5) (2020-05-05)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.4](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.3...@ecomplus/widget-search-engine@1.0.0-beta.4) (2020-05-03)

### Bug Fixes

- **url-query:** fix handling brands and categories from url ([95d351b](https://github.com/ecomplus/storefront/commit/95d351bf4bfa02d9d9afafb8fd0fd4cea51a5c0f))

# [1.0.0-beta.3](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.2...@ecomplus/widget-search-engine@1.0.0-beta.3) (2020-05-01)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.2](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.1...@ecomplus/widget-search-engine@1.0.0-beta.2) (2020-04-23)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.1](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-beta.0...@ecomplus/widget-search-engine@1.0.0-beta.1) (2020-04-16)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-beta.0](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-next.2...@ecomplus/widget-search-engine@1.0.0-beta.0) (2020-04-16)

### Bug Fixes

- **pkg:** update/fix pkg dependencies ([81c2b82](https://github.com/ecomplus/storefront/commit/81c2b824432a1fbd95ea165339258454ee368fd1))

### Features

- **cms:** setup widget cms config ([2b8c1fb](https://github.com/ecomplus/storefront/commit/2b8c1fb72dc8bfbcca35bf836d46fc1c217ae80e))
- **widget-search-engine:** using @ecomplus/storefront-components ([a70e5bb](https://github.com/ecomplus/storefront/commit/a70e5bbab73e9d5317803beab8a8f0ca6a76eebd))

# [1.0.0-next.2](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-next.1...@ecomplus/widget-search-engine@1.0.0-next.2) (2020-04-03)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# [1.0.0-next.1](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@1.0.0-next.0...@ecomplus/widget-search-engine@1.0.0-next.1) (2020-03-28)

### Bug Fixes

- **deps:** update all non-major dependencies ([#171](https://github.com/ecomplus/storefront/issues/171)) ([d94b3fe](https://github.com/ecomplus/storefront/commit/d94b3fec0726e5d92becd3dd53f3833c77bb03cc))

# [1.0.0-next.0](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-search-engine@0.3.5...@ecomplus/widget-search-engine@1.0.0-next.0) (2020-02-27)

**Note:** Version bump only for package @ecomplus/widget-search-engine

# Legacy Change Log

## [0.0.2~0.3.6](/LEGACY_CHANGELOGS/widget-search-engine/v0.0.2~v0.3.6.md)
